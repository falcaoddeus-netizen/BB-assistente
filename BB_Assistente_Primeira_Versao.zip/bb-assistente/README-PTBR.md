# BB — primeira versão

Aplicativo web instalável (PWA) para Android, com chat, reconhecimento de voz do navegador e leitura das respostas em voz alta.

## O que já está pronto
- Interface e chat.
- Endpoint de servidor para conversar com Gemini 2.5 Flash.
- Leitura das respostas com a voz em português disponível no aparelho/navegador.
- Reconhecimento de voz quando o navegador oferece esse recurso.
- Manifesto e service worker para instalação como PWA.
- Configuração inicial para hospedagem no Render (`render.yaml`).

## Antes de publicar
A conexão com a IA só funciona depois de configurar `GEMINI_API_KEY` como variável secreta no servidor. Nunca coloque a chave em `public/index.html`, no GitHub, em prints ou em mensagens. Não compartilhe senhas ou chaves aqui.

A conta Google/API e a hospedagem devem ser criadas e administradas de acordo com os termos de cada serviço; peça a ajuda de um responsável adulto para revisar cadastro, permissões e condições. Não informe dados pessoais ou confidenciais à BB durante os testes.

## Hospedar no Render (plano gratuito para testes)
1. Extraia este ZIP.
2. Um responsável deve ajudar a criar/conectar as contas necessárias, se isso for exigido pelos termos dos serviços.
3. Coloque os arquivos do projeto em um repositório GitHub. Não envie arquivos `.env` nem chaves.
4. No Render, escolha criar um **Blueprint** e conecte o repositório. O arquivo `render.yaml` configura o serviço Node automaticamente.
5. Nas configurações do serviço, adicione `GEMINI_API_KEY` como variável de ambiente secreta. A chave deve ser obtida no painel oficial Google AI Studio; nunca cole a chave neste chat.
6. Salve e faça o deploy. Aguarde o status indicar que o serviço está ativo.
7. Abra a URL HTTPS `*.onrender.com` gerada pelo Render e teste primeiro uma mensagem curta, por exemplo: “Oi, BB, diga olá”.

### Limitações do plano gratuito do Render
- O serviço gratuito pode entrar em repouso após 15 minutos sem acessos; a primeira abertura seguinte pode demorar cerca de um minuto.
- Há limites mensais de horas, tráfego e minutos de build; consulte o painel antes de publicar.
- É indicado para testes e projetos pessoais, não para um serviço que precise ficar sempre disponível.

## Instalar no Android
Depois que o endereço HTTPS estiver funcionando:
1. Abra a URL no Chrome do Android.
2. Abra o menu do Chrome.
3. Toque em **Instalar app** ou **Adicionar à tela inicial**, se essa opção aparecer.
4. Permita o microfone para usar a fala.

## Voz: o que esperar
A leitura usa a síntese de voz do navegador/aparelho e seleciona uma voz em português do Brasil quando disponível. O aparelho pode não oferecer uma voz feminina em pt-BR; isso depende das vozes instaladas. O microfone usa reconhecimento de voz do navegador, que pode não estar disponível em todos os navegadores.

## Limitações desta versão
- Não tem palavra de ativação contínua “Oi, BB”.
- Não escuta em segundo plano e não substitui o assistente do Android.
- O histórico não é salvo permanentemente; ele fica apenas enquanto a página está aberta.
- Não executa ações no celular nem controla dispositivos inteligentes.
- O uso gratuito da Gemini API tem limites que variam por modelo e projeto. Consulte a página oficial de preços e os limites atuais antes de usar. No nível gratuito, as solicitações podem ser usadas para melhorar produtos do Google; não envie informações privadas ou sensíveis.

## Referências oficiais
- Gemini API: https://ai.google.dev/gemini-api/docs
- Preços e nível gratuito: https://ai.google.dev/gemini-api/docs/pricing
- Limites: https://ai.google.dev/gemini-api/docs/rate-limits
- Render gratuito: https://render.com/docs/free
- Primeiro deploy Render: https://render.com/docs/your-first-deploy
