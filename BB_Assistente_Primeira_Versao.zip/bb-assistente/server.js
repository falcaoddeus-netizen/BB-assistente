import express from "express";

const app = express();
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.GEMINI_API_KEY;

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) {
      return res.status(503).json({
        error: "A IA ainda não foi conectada. Configure GEMINI_API_KEY no servidor."
      });
    }

    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const contents = messages.slice(-12).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: String(m.text || "").slice(0, 6000) }]
    })).filter(m => m.parts[0].text.trim());

    if (!contents.length || contents[contents.length - 1].role !== "user") {
      return res.status(400).json({ error: "Envie uma mensagem para a BB." });
    }

    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": API_KEY
        },
        body: JSON.stringify({
          system_instruction: {
            parts: [{
              text: "Você é BB, uma assistente virtual prestativa, educada e acolhedora. Responda em português do Brasil, com clareza e sem inventar fatos. Seja adequada para adolescentes. Não incentive atividades perigosas. Se não souber, diga que não sabe."
            }]
          },
          contents,
          generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      return res.status(502).json({
        error: data?.error?.message || "Não foi possível consultar a IA agora."
      });
    }

    const answer = data?.candidates?.[0]?.content?.parts
      ?.map(p => p.text || "").join("").trim();

    if (!answer) return res.status(502).json({ error: "A IA não retornou uma resposta." });
    res.json({ answer });
  } catch (error) {
    res.status(500).json({ error: "Erro de conexão. Tente novamente." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`BB disponível na porta ${PORT}`));